
  # eclipse

  This is a code bundle for eclipse. The original project is available at https://www.figma.com/design/infnNTdNXOs28RLAK05vx2/eclipse.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  