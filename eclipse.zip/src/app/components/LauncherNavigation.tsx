import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface MenuItem {
  label: string;
  items: string[];
}

const menuItems: MenuItem[] = [
  {
    label: 'SKIN',
    items: ['Steve', 'Alex', 'Custom Skin', 'Download Skins', 'Upload Skin']
  },
  {
    label: 'TEXTURES',
    items: ['Default', 'Faithful', 'PureBDCraft', 'Soartex', 'Custom Pack']
  },
  {
    label: 'MODS',
    items: ['OptiFine', 'Fabric', 'Forge', 'Mod Manager', 'Browse Mods']
  },
  {
    label: 'SERVER',
    items: ['Hypixel', 'Mineplex', 'Wynncraft', 'Add Server', 'Server List']
  }
];

export function LauncherNavigation() {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  return (
    <nav className="flex gap-1 relative">
      {menuItems.map((menu) => (
        <div
          key={menu.label}
          className="relative"
          onMouseEnter={() => setActiveMenu(menu.label)}
          onMouseLeave={() => setActiveMenu(null)}
        >
          <button className="px-6 py-3 bg-transparent border border-white/20 hover:bg-white/5 transition-all duration-200 flex items-center gap-2 group rounded-lg">
            <span className="text-white/90 tracking-wider text-sm font-medium group-hover:text-white">
              {menu.label}
            </span>
            <ChevronDown className="w-4 h-4 text-white/60 group-hover:text-white/90 transition-transform duration-200" 
              style={{ transform: activeMenu === menu.label ? 'rotate(180deg)' : 'rotate(0deg)' }}
            />
          </button>
          
          {activeMenu === menu.label && (
            <div className="absolute top-full left-0 w-48 mt-1 bg-black/60 backdrop-blur-md border border-white/10 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-200 rounded-lg">
              {menu.items.map((item, index) => (
                <button
                  key={index}
                  className="w-full px-4 py-3 text-left text-white/80 hover:bg-white/10 hover:text-white transition-all duration-150 text-sm border-b border-white/5 last:border-b-0"
                >
                  {item}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </nav>
  );
}