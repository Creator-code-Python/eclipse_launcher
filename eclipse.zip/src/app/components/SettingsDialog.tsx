import { useState } from 'react';
import { Settings, X } from 'lucide-react';

export function SettingsDialog() {
  const [isOpen, setIsOpen] = useState(false);
  const [fov, setFov] = useState(90);
  const [theme, setTheme] = useState('dark');
  const [version, setVersion] = useState('1.20.4');

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="p-3 bg-black/40 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-200 group rounded-lg"
      >
        <Settings className="w-5 h-5 text-white/80 group-hover:text-white group-hover:rotate-90 transition-all duration-300" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200">
          <div className="bg-black/80 backdrop-blur-md border border-white/20 w-[500px] p-6 relative rounded-2xl">
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 p-2 hover:bg-white/10 transition-colors duration-200 group"
            >
              <X className="w-5 h-5 text-white/60 group-hover:text-white" />
            </button>

            <h2 className="text-2xl font-bold text-white mb-8 tracking-wider">SETTINGS</h2>

            <div className="space-y-6">
              {/* FOV Setting */}
              <div className="space-y-3">
                <label className="block text-white/80 text-sm tracking-wide uppercase">
                  FOV: <span className="text-white font-bold">{fov}°</span>
                </label>
                <input
                  type="range"
                  min="30"
                  max="110"
                  value={fov}
                  onChange={(e) => setFov(Number(e.target.value))}
                  className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white/40"
                />
                <div className="flex justify-between text-xs text-white/40">
                  <span>30°</span>
                  <span>110°</span>
                </div>
              </div>

              {/* Theme Setting */}
              <div className="space-y-3">
                <label className="block text-white/80 text-sm tracking-wide uppercase">
                  Theme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['dark', 'light', 'gray', 'silent'].map((t) => (
                    <button
                      key={t}
                      onClick={() => setTheme(t)}
                      className={`py-3 px-4 border transition-all duration-200 uppercase text-sm tracking-wide rounded-lg ${
                        theme === t
                          ? 'bg-white/20 border-white/40 text-white'
                          : 'bg-black/40 border-white/10 text-white/60 hover:bg-white/10 hover:text-white/80'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Version Setting */}
              <div className="space-y-3">
                <label className="block text-white/80 text-sm tracking-wide uppercase">
                  Version
                </label>
                <select
                  value={version}
                  onChange={(e) => setVersion(e.target.value)}
                  className="w-full py-3 px-4 bg-black/60 border border-white/10 text-white/90 cursor-pointer hover:bg-white/10 transition-all duration-200 appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22white%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3Cpolyline%20points%3D%226%209%2012%2015%2018%209%22%2F%3E%3C%2Fsvg%3E')] bg-[length:20px] bg-[right_8px_center] bg-no-repeat rounded-lg"
                >
                  <option value="1.20.4">1.20.4 - Latest Release</option>
                  <option value="1.20.3">1.20.3</option>
                  <option value="1.20.2">1.20.2</option>
                  <option value="1.19.4">1.19.4</option>
                  <option value="1.18.2">1.18.2</option>
                  <option value="1.16.5">1.16.5</option>
                  <option value="1.12.2">1.12.2</option>
                  <option value="1.8.9">1.8.9 - PvP</option>
                </select>
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button
                onClick={() => setIsOpen(false)}
                className="flex-1 py-3 bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-200 tracking-wide uppercase text-sm rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="flex-1 py-3 bg-white/90 border border-white text-black hover:bg-white transition-all duration-200 tracking-wide uppercase text-sm font-bold rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}