import { useState } from 'react';
import { LauncherNavigation } from './components/LauncherNavigation';
import { SettingsDialog } from './components/SettingsDialog';
import { Play, User, Globe } from 'lucide-react';

export default function App() {
  const [username, setUsername] = useState('Player');
  const [isLaunching, setIsLaunching] = useState(false);

  const handlePlay = () => {
    setIsLaunching(true);
    setTimeout(() => {
      setIsLaunching(false);
    }, 3000);
  };

  return (
    <div className="size-full relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: `url('https://i.pinimg.com/1200x/51/c9/de/51c9de1f883159047ae82628dd33fb6a.jpg')`
        }}
      />
      
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      
      {/* Content */}
      <div className="relative z-10 size-full flex flex-col">
        {/* Header */}
        <header className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <h1 className="text-3xl font-bold text-white tracking-wider">
              ECLIPSE CLIENT
            </h1>
            <LauncherNavigation />
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg">
              <User className="w-4 h-4 text-white/60" />
              <span className="text-white/80 text-sm">{username}</span>
            </div>
            <SettingsDialog />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex flex-col items-center justify-end px-6 pb-32">
          {/* Play Button */}
          <button
            onClick={handlePlay}
            disabled={isLaunching}
            className="group relative"
          >
            <div className="absolute inset-0 bg-green-500/30 blur-xl group-hover:blur-2xl transition-all duration-300" />
            <div className="relative px-32 py-8 bg-gradient-to-b from-green-400 to-green-500 border-2 border-green-300 hover:from-green-300 hover:to-green-400 transition-all duration-300 flex items-center gap-4 group-hover:scale-105 rounded-2xl">
              {isLaunching ? (
                <>
                  <div className="w-8 h-8 border-4 border-black/20 border-t-black rounded-full animate-spin" />
                  <span className="text-3xl font-bold text-black tracking-wider">
                    LAUNCHING...
                  </span>
                </>
              ) : (
                <>
                  <Play className="w-8 h-8 text-black fill-black" />
                  <span className="text-3xl font-bold text-black tracking-wider">
                    PLAY
                  </span>
                </>
              )}
            </div>
          </button>
        </main>

        {/* Footer */}
        <footer className="p-6 flex items-center justify-end text-white/40 text-xs">
          <div className="flex gap-4">
            <button className="hover:text-white/60 transition-colors">Privacy</button>
            <button className="hover:text-white/60 transition-colors">Terms</button>
            <button className="hover:text-white/60 transition-colors">Support</button>
          </div>
        </footer>
      </div>
    </div>
  );
}